// COMP1521 18s1 Q2 ... shred() function

// put any needed #include's here

void shred(int infd, int outfd)
{
	// put your code here
}
