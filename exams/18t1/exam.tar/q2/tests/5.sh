./shred tests/f5
