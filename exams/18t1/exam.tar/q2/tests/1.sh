./shred tests/f1
