./shred tests/f2
