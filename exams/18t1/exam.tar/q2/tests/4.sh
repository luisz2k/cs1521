./shred tests/f4
