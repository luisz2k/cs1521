./shred tests/f8
