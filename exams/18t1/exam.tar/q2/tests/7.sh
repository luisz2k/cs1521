./shred tests/f7
