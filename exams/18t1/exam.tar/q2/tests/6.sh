./shred tests/f6
