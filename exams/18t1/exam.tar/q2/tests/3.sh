./shred tests/f3
