./shred tests/f9
