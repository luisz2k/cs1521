cp tests/stu1 tests/4.out
./addstu tests/4.out 3334445 "Jack" 3707 45.0
