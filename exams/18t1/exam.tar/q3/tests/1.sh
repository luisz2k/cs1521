cp tests/stu0 tests/1.out
./addstu tests/1.out 3334445 "Jack" 3707 45.0
