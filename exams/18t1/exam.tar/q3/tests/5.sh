cp tests/stu2 tests/5.out
./addstu tests/5.out 5000001 "Jack Jones" 3645 44.4
