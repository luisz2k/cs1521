cp tests/stu1 tests/3.out
./addstu tests/3.out 5134567 Martha 3778 99.9
