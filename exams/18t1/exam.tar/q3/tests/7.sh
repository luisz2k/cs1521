cp tests/stu2 tests/7.out
./addstu tests/7.out 5056789 "Tom Jones" 3778 80.5
