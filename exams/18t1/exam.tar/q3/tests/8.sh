cp tests/stu2 tests/8.out
./addstu tests/8.out 5089999 "Tiny Tim" 3707 30.0
