cp tests/stu2 tests/9.out
./addstu tests/9.out 5100001 "Charlie Jones" 3707 90.0
