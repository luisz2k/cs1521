cp tests/stu1 tests/2.out
./addstu tests/2.out 6054321 "James" 3707 55.0
