cp tests/stu2 tests/6.out
./addstu tests/6.out 5012345 "Jessie James" 3978 85.0
