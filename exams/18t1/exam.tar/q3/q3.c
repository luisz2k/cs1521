// COMP1521 18s1 Q2 ... addStudent() function
// - insert a Student record into a file in order

#include "Students.h"
// put any other required #include's here

void addStudent(int fd, Student stu)
{
	// your code goes here
}
