exe tests/m4.s
