exe tests/m9.s
