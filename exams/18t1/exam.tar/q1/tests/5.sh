exe tests/m5.s
