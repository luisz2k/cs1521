exe tests/m8.s
