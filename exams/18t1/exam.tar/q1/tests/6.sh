exe tests/m6.s
