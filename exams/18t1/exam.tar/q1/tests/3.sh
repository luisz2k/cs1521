exe tests/m3.s
