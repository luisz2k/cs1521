exe tests/m7.s
