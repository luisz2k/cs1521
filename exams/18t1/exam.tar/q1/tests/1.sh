exe tests/m1.s
