exe tests/m2.s
